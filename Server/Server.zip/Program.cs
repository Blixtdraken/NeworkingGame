﻿
using System.Net;
using System.Net.Sockets;
using System.Text;

while (true)
{
    Console.Write("Address: ");
    
    TcpListener listener = new TcpListener(IPAddress.Parse(Console.ReadLine()), 4587);
    TcpClient server;
    listener.Start();
    Console.WriteLine("Server: Trying to connect...");
    server = listener.AcceptTcpClient();
    Console.WriteLine("Server: Connected!");
    listener.Stop();
            
           
                
          


    byte[] buffer = new byte[256];
    while (true)
    {
        try
        {
            server.GetStream().Read(buffer, 0, 256);
                
            Console.WriteLine("Buffer: " + Encoding.ASCII.GetString(buffer));
                    
        }
        catch (IOException e)
        {
            Console.WriteLine("Client discconected!");
            server.Close();
            break;
        }
                
    }
}